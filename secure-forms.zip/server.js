require('dotenv').config();
const express = require('express');
const multer = require('multer');
const sqlite3 = require('sqlite3').verbose(); // Local only; we'll swap for Postgres later
const crypto = require('crypto');
const fs = require('fs');
const nodemailer = require('nodemailer');
const path = require('path');
const helmet = require('helmet'); // Security headers
const rateLimit = require('express-rate-limit'); // Rate limiting
const csrf = require('csurf'); // CSRF protection
const cookieParser = require('cookie-parser'); // For CSRF
const Joi = require('joi'); // Validation

const app = express();
const PORT = process.env.PORT || 3000;

// Load master key from env for security (generate new one!)
const MASTER_KEY = process.env.MASTER_KEY_HEX || fs.readFileSync('master.key', 'utf8').trim(); // Use env in prod

// SQLite (local only)
const db = new sqlite3.Database('submissions.db', (err) => {
  if (err) console.error('DB error:', err);
  else console.log('Connected to DB.');
});
db.run(`CREATE TABLE IF NOT EXISTS submissions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  encrypted_data BLOB,
  files TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)`);

// Multer with limits
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/'),
  filename: (req, file, cb) => cb(null, `${Date.now()}-${file.originalname}`)
});
const upload = multer({ 
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/') || file.mimetype === 'application/pdf') cb(null, true);
    else cb(new Error('Only images/PDFs allowed'), false);
  }
});

// Middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      ...helmet.contentSecurityPolicy.getDefaultDirectives(),
      'script-src': ["'self'", "'unsafe-inline'"]
    }
  }
})); // Security headers
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cookieParser());
app.use(express.static('views'));
app.use('/uploads', express.static('uploads')); // Local only; Supabase in prod

// Rate limiting: 5 submits/IP/hour
const limiter = rateLimit({ windowMs: 60 * 60 * 1000, max: 5 });
app.use('/submit', limiter);

// CSRF (after cookieParser)
const csrfProtection = csrf({ cookie: true });
app.use(csrfProtection); // Apply to form routes

// HTTPS redirect (for prod)
app.use((req, res, next) => {
  if (req.header('x-forwarded-proto') !== 'https' && process.env.NODE_ENV === 'production') {
    return res.redirect(301, `https://${req.header('host')}${req.url}`);
  }
  next();
});

// Basic Auth Middleware (reusable)
const requireAuth = (req, res, next) => {
  const b64auth = (req.headers.authorization || '').split(' ')[1] || '';
  const [login, password] = Buffer.from(b64auth, 'base64').toString().split(':');
  if (login === process.env.ADMIN_USER && password === process.env.ADMIN_PASS) {
    return next();
  }
  res.set('WWW-Authenticate', 'Basic realm="Secure Area"').status(401).send('Unauthorized');
};

// Routes
app.get('/', csrfProtection, (req, res) => {
  res.sendFile(path.join(__dirname, 'views/form.html'));
});

// Pass CSRF token to form
app.get('/csrf-token', (req, res) => res.json({ csrfToken: req.csrfToken() })); // No protection on GET token endpoint

app.post('/submit', csrfProtection, upload.fields([
  { name: 'id_front', maxCount: 1 },
  { name: 'id_back', maxCount: 1 },
  { name: 'utility_bill', maxCount: 1 }
]), async (req, res) => {
  try {
    const data = req.body;

    // Validation with Joi
    const schema = Joi.object({
      full_name: Joi.string().required(),
      dob: Joi.date().required(),
      email: Joi.string().email().required(),
      phone: Joi.string().pattern(/^\d{10,15}$/).required(),
      street_address: Joi.string().required(),
      city: Joi.string().required(),
      state: Joi.string().valid(...Array.from({length: 50}, (_, i) => `State ${i+1}`)).required(), // Simplified
      zip: Joi.string().pattern(/^\d{5}(-\d{4})?$/).required(),
      ssn: Joi.string().pattern(/^\d{3}-\d{2}-\d{4}$/).required(),
      work_permit: Joi.string().valid('Yes', 'No').required(),
      online_access: Joi.string().valid('Yes', 'No').required(),
      signature: Joi.string().required(),
      signature_date: Joi.date().required(),
      bank_name: Joi.string().allow(''),
      account_number: Joi.string().allow(''),
      routing_number: Joi.string().allow(''),
      ref1: Joi.string().allow(''),
      ref2: Joi.string().allow('')
    });
    const { error } = schema.validate(data);
    if (error) return res.status(400).send(`Validation error: ${error.details[0].message}`);

    // Encrypt ALL data
    const allData = { ...data, files: Object.values(req.files || {}).flat().map(f => f.filename) };
    const iv = crypto.randomBytes(12);
    const cipher = crypto.createCipheriv('aes-256-gcm', Buffer.from(MASTER_KEY, 'hex'), iv);
    let encrypted = cipher.update(JSON.stringify(allData), 'utf8', 'base64');
    encrypted += cipher.final('base64');
    const authTag = cipher.getAuthTag().toString('base64');
    const encryptedPayload = JSON.stringify({ iv: iv.toString('base64'), authTag, data: encrypted });

    // Insert (no plaintext fields)
    db.run('INSERT INTO submissions (encrypted_data, files) VALUES (?, ?)',
      [encryptedPayload, JSON.stringify(allData.files || [])],
      (err) => { if (err) console.error('DB insert:', err); }
    );

    // Email (same as before)
    const transporter = nodemailer.createTransporter({
      host: process.env.EMAIL_HOST,
      port: process.env.EMAIL_PORT,
      secure: process.env.EMAIL_SECURE === 'true', // Set to true for TLS
      auth: { user: process.env.EMAIL_USER, pass: process.env.EMAIL_PASS }
    });
    await transporter.sendMail({
      from: process.env.EMAIL_FROM,
      to: process.env.EMAIL_TO,
      subject: 'New Submission',
      text: `Received at ${new Date().toISOString()}. Check admin panel.`
    });

    res.send('<h2>Submitted! Check email.</h2><a href="/">Back</a>');
  } catch (err) {
    console.error('Submit error:', err); // Log but don't expose
    res.status(500).send('Server error. Try again.');
  }
});

app.get('/admin', requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'views/admin.html'));
});

// PROTECTED API
app.get('/api/submissions', requireAuth, (req, res) => {
  db.all('SELECT * FROM submissions ORDER BY created_at DESC', [], (err, rows) => {
    if (err) return res.status(500).json({ error: 'DB error' });

    const decryptedRows = rows.map(row => {
      try {
        const enc = JSON.parse(row.encrypted_data);
        const iv = Buffer.from(enc.iv, 'base64');
        const authTag = Buffer.from(enc.authTag, 'base64');
        const decipher = crypto.createDecipheriv('aes-256-gcm', Buffer.from(MASTER_KEY, 'hex'), iv);
        decipher.setAuthTag(authTag);
        const decrypted = decipher.update(enc.data, 'base64', 'utf8') + decipher.final('utf8');
        const data = JSON.parse(decrypted);
        return { ...row, data, files: data.files || [] };
      } catch (e) {
        console.error('Decrypt error:', e);
        return { ...row, data: { error: 'Decrypt failed' }, files: [] };
      }
    });
    res.json(decryptedRows);
  });
});

app.listen(PORT, () => console.log(`Server on http://localhost:${PORT}`));